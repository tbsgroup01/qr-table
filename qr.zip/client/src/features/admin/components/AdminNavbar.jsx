import { Link, useNavigate } from "react-router-dom";
import { Sun, Moon, LogOut } from "lucide-react";
import { useTheme } from "../../../context/ThemeContext";
import logoImage from "../../../assets/qr.png";

export default function AdminNavbar() {
  const navigate = useNavigate();
  const { theme, setTheme, isDark } = useTheme();

  return (
    <header
      className={`w-full h-[72px] ${
        isDark
          ? "bg-[#070913]/90 border-white/[0.08] text-white shadow-[0_4px_20px_rgba(0,0,0,0.4)]"
          : "bg-white/95 border-slate-200 text-slate-900 shadow-sm"
      } backdrop-blur-2xl border-b sticky top-0 z-50 flex items-center justify-between px-4 sm:px-6 select-none transition-colors duration-300`}
    >
      <div className="flex items-center shrink-0">
        <Link
          to="/admin"
          className="flex items-center gap-2 group overflow-hidden"
          title="QuickTable Admin"
        >
          <img
            src={logoImage}
            alt="QuickTable"
            className="h-20 max-w-[200px] object-contain group-hover:scale-105 transition-transform"
          />
        </Link>
      </div>

      <div className="flex items-center gap-3 sm:gap-4 shrink-0">
        <div
          className={`rounded-full p-1 flex items-center shadow-inner border ${
            isDark
              ? "bg-[#0e1224] border-[#1b2244]"
              : "bg-slate-100 border-slate-200"
          }`}
        >
          <button
            type="button"
            onClick={() => setTheme("light")}
            className={`px-2.5 sm:px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              theme === "light"
                ? "bg-white text-orange-600 shadow-sm font-bold"
                : "text-slate-400 hover:text-slate-700"
            }`}
          >
            <Sun
              size={13}
              className={theme === "light" ? "text-amber-500" : ""}
            />
            <span>Day</span>
          </button>

          <button
            type="button"
            onClick={() => setTheme("dark")}
            className={`px-2.5 sm:px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              theme === "dark"
                ? "bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-sm shadow-orange-500/25 font-bold"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Moon size={13} fill={theme === "dark" ? "currentColor" : "none"} />
            <span>Night</span>
          </button>
        </div>

        <div
          className={`rounded-full py-1 pl-1 pr-3 sm:pr-4 flex items-center gap-2.5 cursor-pointer transition-colors shadow-sm border ${
            isDark
              ? "bg-[#0e1224] border-[#1b2244] hover:border-orange-500/40 text-white"
              : "bg-slate-100 border-slate-200 hover:border-orange-500/40 text-slate-800"
          }`}
        >
          <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-orange-500 to-amber-400 text-white font-bold text-xs flex items-center justify-center shadow-sm shadow-orange-500/25 shrink-0">
            S
          </div>
          <span className="text-xs font-bold hidden sm:inline">Super Admin</span>
        </div>

        <button
          type="button"
          onClick={() => navigate("/")}
          className={`p-2 rounded-xl border flex items-center justify-center transition-all cursor-pointer ${
            isDark
              ? "bg-[#0e1224] border-[#1b2244] text-red-400 hover:text-red-300 hover:border-red-500/40"
              : "bg-slate-100 border-slate-200 text-slate-500 hover:text-red-600 hover:border-red-300"
          }`}
          title="Sign Out"
          aria-label="Sign Out"
        >
          <LogOut size={16} />
        </button>
      </div>
    </header>
  );
}

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Store,
  Users,
  Gamepad2,
  IndianRupee,
  Database,
  ArrowRight,
  UserPlus,
  Layers,
  BarChart3,
} from "lucide-react";
import { useTheme } from "../../../context/ThemeContext";
import Cards from "../../../components/Cards";
import { getAllRestaurants } from "../../../services/restroServices";
import { getAllTransactions } from "../../../services/revenueServices";

export default function Dashboard() {
  const { isDark } = useTheme();
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [restaurantCount, setRestaurantCount] = useState(0);

  useEffect(() => {
    getAllRestaurants()
      .then((res) => {
        if (res?.success && Array.isArray(res.data)) {
          setRestaurantCount(res.data.length);
        }
      })
      .catch((err) => console.warn("Dashboard restro fetch:", err));

    getAllTransactions()
      .then((res) => {
        if (res?.success && res.metrics?.platformRevenue !== undefined) {
          setTotalRevenue(res.metrics.platformRevenue);
        } else if (res?.data && Array.isArray(res.data)) {
          const sum = res.data.reduce((acc, t) => acc + (parseFloat(t.amount) || 0), 0);
          setTotalRevenue(sum);
        }
      })
      .catch((err) => console.warn("Dashboard revenue fetch:", err));
  }, []);

  const metricCards = [
    {
      title: "Total Restaurants",
      value: String(restaurantCount || 0),
      icon: Store,
      iconColor: "text-blue-500 dark:text-blue-400",
      iconBg: "bg-blue-500/10 border-blue-500/20",
      glowColor: "from-blue-500/20 via-blue-500/5 to-transparent",
      accentBorder: "hover:border-blue-500/40",
    },
    {
      title: "Total Players",
      value: "1",
      icon: Users,
      iconColor: "text-purple-500 dark:text-purple-400",
      iconBg: "bg-purple-500/10 border-purple-500/20",
      glowColor: "from-purple-500/20 via-purple-500/5 to-transparent",
      accentBorder: "hover:border-purple-500/40",
    },
    {
      title: "Games Played Today",
      value: "0",
      icon: Gamepad2,
      iconColor: "text-cyan-500 dark:text-cyan-400",
      iconBg: "bg-cyan-500/10 border-cyan-500/20",
      glowColor: "from-cyan-500/20 via-cyan-500/5 to-transparent",
      accentBorder: "hover:border-cyan-500/40",
    },
    {
      title: "Platform Revenue",
      value: `₹${totalRevenue.toLocaleString("en-IN")}`,
      icon: IndianRupee,
      iconColor: "text-emerald-500 dark:text-emerald-400",
      iconBg: "bg-emerald-500/10 border-emerald-500/20",
      glowColor: "from-emerald-500/20 via-emerald-500/5 to-transparent",
      accentBorder: "hover:border-emerald-500/40",
    },
  ];
  const onboardedRestaurants = [
    {
      id: 1,
      name: "Raju Dhaba",
      initial: "R",
      avatarBg: "bg-blue-500/20 text-blue-600 dark:text-blue-400 border-blue-500/30",
      owner: "Raju",
      plan: "STARTER",
      planColor: "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400",
      tablesLimit: "0 max",
      status: "Active",
      joined: "Nov 2026",
    },
    {
      id: 2,
      name: "Raju Dhaba",
      initial: "R",
      avatarBg: "bg-blue-500/20 text-blue-600 dark:text-blue-400 border-blue-500/30",
      owner: "Test Raju",
      plan: "STARTER",
      planColor: "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400",
      tablesLimit: "0 max",
      status: "Active",
      joined: "Nov 2026",
    },
    {
      id: 3,
      name: "Burger Palace",
      initial: "B",
      avatarBg: "bg-purple-500/20 text-purple-600 dark:text-purple-400 border-purple-500/30",
      owner: "James Walker",
      plan: "PREMIUM",
      planColor: "bg-purple-500/15 border-purple-500/30 text-purple-600 dark:text-purple-300",
      tablesLimit: "5 max",
      status: "Active",
      joined: "Nov 2026",
    },
  ];
  const quickActions = [
    {
      label: "Check Restaurant",
      to: "/admin/restaurants",
      icon: Store,
      color: "text-purple-600 dark:text-purple-400",
      bg: "bg-purple-50 dark:bg-purple-500/10 border-purple-200/80 dark:border-purple-500/20 hover:border-purple-500/40",
    },
    {
      label: "User",
      to: "/admin/users",
      icon: UserPlus,
      color: "text-blue-600 dark:text-blue-400",
      bg: "bg-blue-50 dark:bg-blue-500/10 border-blue-200/80 dark:border-blue-500/20 hover:border-blue-500/40",
    },
    {
      label: "Manage Plans",
      to: "/admin/plans",
      icon: Layers,
      color: "text-amber-600 dark:text-amber-400",
      bg: "bg-amber-50 dark:bg-amber-500/10 border-amber-200/80 dark:border-amber-500/20 hover:border-amber-500/40",
    },
    {
      label: "View Revenue",
      to: "/admin/revenue",
      icon: BarChart3,
      color: "text-emerald-600 dark:text-emerald-400",
      bg: "bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200/80 dark:border-emerald-500/20 hover:border-emerald-500/40",
    },
  ];

  const yTicks = [
    { label: "₹6,000", y: 20 },
    { label: "₹4,500", y: 55 },
    { label: "₹3,000", y: 92 },
    { label: "₹1,500", y: 130 },
    { label: "₹0", y: 168 },
  ];

  const chartPoints = [
    { month: "Jun", x: 45, y: 146 },
    { month: "Jul", x: 145, y: 134 },
    { month: "Aug", x: 245, y: 110 },
    { month: "Sep", x: 345, y: 104 },
    { month: "Oct", x: 445, y: 84 },
    { month: "Nov", x: 545, y: 38 },
  ];

  return (
    <div className="space-y-4 sm:space-y-5 xl:space-y-6 pb-12 select-none">
      <header data-aos="fade-down" data-aos-duration="500" className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4 relative">
        <div>
          <div className="flex items-center gap-3 flex-wrap">
            <h1
              className={`text-xl sm:text-2xl xl:text-3xl font-extrabold tracking-tight leading-none ${
                isDark ? "text-white" : "text-slate-900"
              }`}
            >
              Platform Overview
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time system health, restaurant tenancy, and SaaS subscription metrics
          </p>
        </div>
      </header>

      {/* 2. Top Metric Cards (Rendered from Cards Component) */}
      <Cards items={metricCards} />

      {/* 3. Middle Row: Spline Line Chart (6 cols) + Subscription Distribution (3 cols) + Quick Actions (3 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 sm:gap-4 xl:gap-5 items-stretch">
        {/* Left: Revenue Growth Trajectory (INR ₹) - 6 cols */}
        <div
          data-aos="fade-up"
          data-aos-delay="100"
          className={`lg:col-span-6 p-4 sm:p-4.5 xl:p-6 rounded-xl sm:rounded-2xl border shadow-xl flex flex-col justify-between space-y-3 xl:space-y-4 ${
            isDark
              ? "bg-white/[0.03] backdrop-blur-2xl border-white/[0.08]"
              : "bg-white/60 backdrop-blur-2xl border-white/70 "
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 sm:gap-3">
            <div>
              <h2
                className={`text-sm sm:text-base xl:text-lg font-bold tracking-tight ${
                  isDark ? "text-white" : "text-slate-900"
                }`}
              >
                Revenue Growth Trajectory (INR ₹)
              </h2>
              <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
                Real-time collections across all venue subscriptions and table orders
              </p>
            </div>

            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 xl:px-3 xl:py-1 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 text-[10px] sm:text-xs font-semibold self-start sm:self-auto shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Live Sync
            </span>
          </div>

          {/* Curved Line / Spline Chart View */}
          <div className="relative pt-1 pb-1">
            <svg
              viewBox="0 0 600 215"
              className="w-full h-auto overflow-visible select-none"
            >
              <defs>
                {/* Purple Area Gradient */}
                <linearGradient
                  id="revenueGradient"
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop
                    offset="0%"
                    stopColor="#8b5cf6"
                    stopOpacity={isDark ? "0.35" : "0.22"}
                  />
                  <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.0" />
                </linearGradient>

                {/* Line Gradient */}
                <linearGradient
                  id="revenueLine"
                  x1="0"
                  y1="0"
                  x2="1"
                  y2="0"
                >
                  <stop offset="0%" stopColor="#7c3aed" />
                  <stop offset="50%" stopColor="#8b5cf6" />
                  <stop offset="100%" stopColor="#a855f7" />
                </linearGradient>
              </defs>

              {/* Horizontal Grid Lines & Y-Axis Labels */}
              {yTicks.map((tick) => (
                <g key={tick.label}>
                  <text
                    x="35"
                    y={tick.y + 4}
                    textAnchor="end"
                    className="text-[10px] fill-slate-400 font-medium"
                  >
                    {tick.label}
                  </text>
                  <line
                    x1="45"
                    y1={tick.y}
                    x2="575"
                    y2={tick.y}
                    stroke={isDark ? "#334155" : "#e2e8f0"}
                    strokeDasharray="4 4"
                    strokeWidth="1"
                    opacity={isDark ? "0.4" : "0.8"}
                  />
                </g>
              ))}

              {/* Area Under Curve */}
              <path
                d="M 45 146 C 95 142, 115 136, 145 134 C 185 130, 215 116, 245 110 C 285 106, 315 106, 345 104 C 385 100, 415 92, 445 84 C 485 72, 515 48, 545 38 L 545 168 L 45 168 Z"
                fill="url(#revenueGradient)"
              />

              {/* Smooth Curved Line */}
              <path
                d="M 45 146 C 95 142, 115 136, 145 134 C 185 130, 215 116, 245 110 C 285 106, 315 106, 345 104 C 385 100, 415 92, 445 84 C 485 72, 515 48, 545 38"
                fill="none"
                stroke="url(#revenueLine)"
                strokeWidth="3.5"
                strokeLinecap="round"
              />

              {/* Data Point Circles on Spline */}
              {chartPoints.map((pt) => {
                const isNov = pt.month === "Nov";
                return (
                  <g key={pt.month}>
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isNov ? "5" : "4"}
                      className="fill-[#7c3aed] stroke-white dark:stroke-[#070913] stroke-2 transition-all cursor-pointer hover:r-6"
                    />
                    {/* X-Axis Month Label */}
                    <text
                      x={pt.x}
                      y="192"
                      textAnchor="middle"
                      className={`text-[11px] font-semibold ${
                        isNov
                          ? "fill-[#8b5cf6]"
                          : isDark
                          ? "fill-slate-400"
                          : "fill-slate-500"
                      }`}
                    >
                      {pt.month}
                    </text>
                  </g>
                );
              })}

              {/* Nov Badge: ₹5,250 pill floating directly over peak point */}
              <g transform="translate(545, 38)">
                <rect
                  x="-32"
                  y="-28"
                  width="64"
                  height="22"
                  rx="6"
                  className="fill-[#7c3aed] filter drop-shadow-md"
                />
                <text
                  x="0"
                  y="-13"
                  textAnchor="middle"
                  className="text-[10px] font-extrabold fill-white"
                >
                  ₹5,250
                </text>
              </g>
            </svg>
          </div>
        </div>

        {/* Middle: Subscription Distribution Donut Chart - 3 cols */}
        <div
          data-aos="fade-up"
          data-aos-delay="200"
          className={`lg:col-span-3 p-3.5 sm:p-4 xl:p-5 rounded-xl sm:rounded-2xl border shadow-xl flex flex-col justify-between space-y-2.5 xl:space-y-3.5 ${
            isDark
              ? "bg-white/[0.03] backdrop-blur-2xl border-white/[0.08]"
              : "bg-white/60 backdrop-blur-2xl border-white/70 shadow-[0_8px_30px_rgba(0,0,0,0.04)]"
          }`}
        >
          <div className="flex items-center justify-between">
            <h2
              className={`text-xs sm:text-sm xl:text-base font-bold tracking-tight ${
                isDark ? "text-white" : "text-slate-900"
              }`}
            >
              Subscription Distribution
            </h2>
            <span className="text-[10px] sm:text-[11px] font-semibold text-slate-400">
              Active Tiers
            </span>
          </div>

          <div className="flex flex-col items-center justify-between gap-2 py-0.5 flex-1">
            {/* SVG Donut Chart (Responsive compact size for 511px-800px heights) */}
            <div className="relative w-28 h-28 sm:w-32 sm:h-32 xl:w-36 xl:h-36 shrink-0 my-auto">
              <svg
                viewBox="0 0 120 120"
                className="w-full h-full -rotate-90 transform"
              >
                {/* Background Ring */}
                <circle
                  cx="60"
                  cy="60"
                  r="44"
                  fill="none"
                  stroke={isDark ? "#1e293b" : "#f1f5f9"}
                  strokeWidth="13"
                />

                {/* Starter Plan Arc (Green, 66.7%) */}
                <circle
                  cx="60"
                  cy="60"
                  r="44"
                  fill="none"
                  stroke="#22c55e"
                  strokeWidth="13"
                  strokeDasharray="184.3 276.46"
                  strokeDashoffset="0"
                  className="transition-all duration-700"
                />

                {/* Premium Plan Arc (Purple, 33.3%) */}
                <circle
                  cx="60"
                  cy="60"
                  r="44"
                  fill="none"
                  stroke="#a855f7"
                  strokeWidth="13"
                  strokeDasharray="92.1 276.46"
                  strokeDashoffset="-184.3"
                  className="transition-all duration-700"
                />
              </svg>

              {/* Center Value */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span
                  className={`text-xl sm:text-2xl font-black leading-none ${
                    isDark ? "text-white" : "text-slate-900"
                  }`}
                >
                  3
                </span>
                <span className="text-[10px] sm:text-xs font-semibold text-slate-400 mt-0.5">
                  Restaurants
                </span>
              </div>
            </div>

            {/* Well-spaced, balanced Plan Breakdown List (Truncation Safe) */}
            <div className="w-full space-y-1.5 pt-1">
              {/* Starter Plan */}
              <div
                className={`flex items-center justify-between p-1.5 sm:p-2 xl:p-2.5 rounded-xl border transition-colors ${
                  isDark
                    ? "bg-white/[0.025] border-white/[0.06]"
                    : "bg-white/70 border-slate-200/80 shadow-xs"
                }`}
              >
                <div className="flex items-center gap-1.5 min-w-0 flex-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 shadow-xs shadow-emerald-500/50" />
                  <span
                    className={`font-bold text-[11px] xl:text-xs truncate ${
                      isDark ? "text-slate-200" : "text-slate-800"
                    }`}
                  >
                    Starter Plan
                  </span>
                </div>
                <span className="font-bold text-emerald-600 dark:text-emerald-400 whitespace-nowrap text-[11px] xl:text-xs shrink-0 ml-1.5">
                  2 (66.7%)
                </span>
              </div>

              {/* Premium Plan */}
              <div
                className={`flex items-center justify-between p-1.5 sm:p-2 xl:p-2.5 rounded-xl border transition-colors ${
                  isDark
                    ? "bg-white/[0.025] border-white/[0.06]"
                    : "bg-white/70 border-slate-200/80 shadow-xs"
                }`}
              >
                <div className="flex items-center gap-1.5 min-w-0 flex-1">
                  <span className="w-2 h-2 rounded-full bg-purple-500 shrink-0 shadow-xs shadow-purple-500/50" />
                  <span
                    className={`font-bold text-[11px] xl:text-xs truncate ${
                      isDark ? "text-slate-200" : "text-slate-800"
                    }`}
                  >
                    Premium Plan
                  </span>
                </div>
                <span className="font-bold text-purple-600 dark:text-purple-400 whitespace-nowrap text-[11px] xl:text-xs shrink-0 ml-1.5">
                  1 (33.3%)
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Quick Actions - 3 cols (Compact, completely responsive) */}
        <div
          data-aos="fade-up"
          data-aos-delay="300"
          className={`lg:col-span-3 p-3.5 sm:p-4 xl:p-5 rounded-xl sm:rounded-2xl border shadow-xl flex flex-col justify-between space-y-2.5 xl:space-y-3.5 ${
            isDark
              ? "bg-white/[0.03] backdrop-blur-2xl border-white/[0.08]"
              : "bg-white/60 backdrop-blur-2xl border-white/70 shadow-[0_8px_30px_rgba(0,0,0,0.04)]"
          }`}
        >
          <div className="flex items-center justify-between">
            <h2
              className={`text-xs sm:text-sm xl:text-base font-bold tracking-tight ${
                isDark ? "text-white" : "text-slate-900"
              }`}
            >
              Quick Actions
            </h2>
            <span className="text-[10px] sm:text-[11px] font-semibold text-slate-400">
              Shortcuts
            </span>
          </div>

          {/* 4 Action Cards in a 2x2 Grid - tight height so all 4 fit seamlessly */}
          <div className="grid grid-cols-2 gap-2 xl:gap-2.5 flex-1 py-0.5">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Link
                  key={action.label}
                  to={action.to}
                  className={`p-2 sm:p-2.5 xl:p-3 rounded-xl border flex flex-col items-center justify-center text-center gap-1.5 transition-all duration-200 group cursor-pointer shadow-xs hover:scale-[1.02] active:scale-95 ${action.bg}`}
                >
                  <div
                    className={`w-8 h-8 sm:w-9 sm:h-9 xl:w-10 xl:h-10 rounded-lg bg-white dark:bg-slate-800/90 shadow-xs flex items-center justify-center shrink-0 ${action.color} group-hover:scale-105 transition-transform`}
                  >
                    <Icon size={18} className="stroke-[2.2]" />
                  </div>
                  <span
                    className={`text-[10.5px] sm:text-[11px] xl:text-xs font-bold leading-tight line-clamp-1 truncate w-full text-center ${
                      isDark ? "text-slate-200" : "text-slate-800"
                    }`}
                    title={action.label}
                  >
                    {action.label}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. Bottom Row: Real Onboarded Restaurants Table (Full Width) */}
      <div
        data-aos="fade-up"
        data-aos-delay="200"
        className={`p-4 sm:p-4.5 xl:p-6 rounded-xl sm:rounded-2xl border shadow-xl flex flex-col justify-between space-y-3 sm:space-y-4 ${
          isDark
            ? "bg-white/[0.03] backdrop-blur-2xl border-white/[0.08]"
            : "bg-white/60 backdrop-blur-2xl border-white/70 shadow-[0_8px_30px_rgba(0,0,0,0.04)]"
        }`}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <h2
              className={`text-sm sm:text-base xl:text-lg font-bold tracking-tight truncate ${
                isDark ? "text-white" : "text-slate-900"
              }`}
            >
              Real Onboarded Restaurants
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-600 dark:text-cyan-400 text-[9px] sm:text-[10px] font-extrabold tracking-wider shrink-0">
              3 Registered
            </span>
          </div>

          <Link
            to="/admin/restaurants"
            className="text-[11px] sm:text-xs font-semibold text-slate-400 hover:text-orange-500 flex items-center gap-1 transition-colors group cursor-pointer shrink-0"
          >
            <span>Manage All Venues</span>
            <ArrowRight
              size={12}
              className="group-hover:translate-x-1 transition-transform"
            />
          </Link>
        </div>

        {/* Table Container */}
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr
                className={`border-b text-[10px] xl:text-[11px] font-bold text-slate-400 uppercase tracking-wider ${
                  isDark ? "border-white/[0.06]" : "border-slate-200"
                }`}
              >
                <th className="py-2 xl:py-2.5 px-2">RESTAURANT</th>
                <th className="py-2 xl:py-2.5 px-2">OWNER</th>
                <th className="py-2 xl:py-2.5 px-2">PLAN</th>
                <th className="py-2 xl:py-2.5 px-2">TABLES LIMIT</th>
                <th className="py-2 xl:py-2.5 px-2">STATUS</th>
                <th className="py-2 xl:py-2.5 px-2 text-right">JOINED</th>
              </tr>
            </thead>
            <tbody
              className={`divide-y text-xs ${
                isDark ? "divide-white/[0.04]" : "divide-slate-100"
              }`}
            >
              {onboardedRestaurants.map((resto) => (
                <tr
                  key={resto.id}
                  className={`transition-colors group ${
                    isDark
                      ? "hover:bg-white/[0.025]"
                      : "hover:bg-slate-50/80"
                  }`}
                >
                  {/* Restaurant Name with Avatar */}
                  <td className="py-2.5 xl:py-3 px-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-semibold text-xs xl:text-sm truncate max-w-[140px] xl:max-w-none transition-colors group-hover:text-orange-500 ${
                          isDark ? "text-white" : "text-slate-800"
                        }`}
                      >
                        {resto.name}
                      </span>
                    </div>
                  </td>

                  {/* Owner */}
                  <td
                    className={`py-2.5 xl:py-3 px-2 truncate max-w-[110px] xl:max-w-none text-[11px] xl:text-xs ${
                      isDark ? "text-slate-300" : "text-slate-600"
                    }`}
                  >
                    {resto.owner}
                  </td>

                  {/* Plan */}
                  <td className="py-2.5 xl:py-3 px-2">
                    <span
                      className={`px-2 py-0.5 rounded-md border ${resto.planColor} text-[9px] xl:text-[10px] font-extrabold tracking-wider`}
                    >
                      {resto.plan}
                    </span>
                  </td>

                  {/* Tables Limit */}
                  <td className="py-2.5 xl:py-3 px-2 text-[10px] xl:text-[11px] text-slate-400 truncate">
                    {resto.tablesLimit}
                  </td>

                  {/* Status with green dot */}
                  <td className="py-2.5 xl:py-3 px-2">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 text-[10px] xl:text-[11px] font-semibold">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      {resto.status}
                    </span>
                  </td>

                  {/* Joined Date */}
                  <td className="py-2.5 xl:py-3 px-2 text-slate-400 text-[10px] xl:text-[11px] text-right whitespace-nowrap">
                    {resto.joined}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
